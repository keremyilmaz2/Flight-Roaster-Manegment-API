﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Flight_Roaster_Manegment_API.Migrations
{
    /// <inheritdoc />
    public partial class AddUserGneder : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Gender",
                table: "Users",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Gender",
                table: "Users");
        }
    }
}
