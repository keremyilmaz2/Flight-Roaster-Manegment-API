﻿namespace FlightRosterAPI.Models.Enums
{
    public enum CabinCrewType
    {
        Regular = 1,    // Normal görevli
        Chief = 2,      // Baş kabin görevlisi
        Chef = 3        // Aşçı
    }
}