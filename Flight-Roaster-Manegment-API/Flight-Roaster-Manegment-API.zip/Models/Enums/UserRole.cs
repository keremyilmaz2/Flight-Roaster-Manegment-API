﻿namespace FlightRosterAPI.Models.Enums
{
    public enum UserRole
    {
        Passenger = 1,
        Admin = 2,
        Pilot = 3,
        CabinCrew = 4
    }
}