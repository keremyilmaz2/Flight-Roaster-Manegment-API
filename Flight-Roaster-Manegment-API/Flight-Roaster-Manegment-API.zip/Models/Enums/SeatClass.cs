﻿namespace FlightRosterAPI.Models.Enums
{
    public enum SeatClass
    {
        Economy = 1,
        Business = 2
    }
}