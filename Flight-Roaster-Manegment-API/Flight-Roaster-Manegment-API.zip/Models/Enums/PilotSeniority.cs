﻿namespace FlightRosterAPI.Models.Enums
{
    public enum PilotSeniority
    {
        Trainee = 1,
        Junior = 2,
        Senior = 3
    }
}