﻿namespace FlightRosterAPI.Models.Enums
{
    public enum CabinCrewSeniority
    {
        Junior = 1,
        Senior = 2
    }
}